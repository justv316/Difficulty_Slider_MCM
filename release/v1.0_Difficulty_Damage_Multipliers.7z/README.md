# [ObRe 1.2] Dynamic Difficulty Multiplier (MCM)

# Changelog
1.0
* Complete rebuild and re-release. 

## Description

* Mod Configuration Menu (MCM) for controlling the Difficulty Damage Multiplier for all 1.2 difficulties.

* As of version 1.2, ObRe now calcuates damage done based on 2 different sliders the player chooses. Dicene explored UE and found 12 new game settings that govern damage done and dealt. This mod is built to dynamically adjust all of those settings depending on the player set fDamageDifficultyMultiplier. 


### Prerequisites
1. [UE4SS](https://www.nexusmods.com/oblivionremastered/mods/32)
	1. [Mad OBScript Extender v2.0a or Later](https://www.nexusmods.com/oblivionremastered/mods/4819)
	2. [Mad Config Menu MCM v3.6 or later](https://www.nexusmods.com/oblivionremastered/mods/4810)
	
### Installation
0. Install Prerequisites
1. Copy Difficulty_Damage_Multipliers.esp to `\Oblivion Remastered\OblivionRemastered\Content\Dev\ObvData\Data`
	1. Add `Difficulty_Damage_Multipliers.esp` to your Plugins.txt
2. Copy Difficulty_Damage_Multipliers.ini to `\Oblivion Remastered\OblivionRemastered\Binaries\Win64\MadConfigs`

### Uninstallation
0. MCM Reset Method (Preferred)
	0. In the MCM, press 'Reset' to restore the Difficulty Settings to their default values before removing the Ini and ESP file
	
1. Batch file Method
	0. If you have already removed the ESP and INI file, and still need to restore default settings, do the following. 
	1. Download Restore_Difficulty.txt from GitHub [Link](https://github.com/justv316/Difficulty_Slider_MCM/blob/main/src/OblivionRemastered/Restore_Difficulty.txt)
	2. Copy the txt file to `\Oblivion Remastered\OblivionRemastered\Binaries`
	3. While In-game, press the ~ key to open the console, type `exec Restore_Difficulty` and press enter.
	4. The default settings have now been restored

2. Manual Method
	0. While In-game, press the ~ key to open the console. Type each command and press enter.
		`SetGameSetting fDifficultyDamageDealtMultiplierNovice -5`
		`SetGameSetting fDifficultyDamageTakenMultiplierNovice -5`
		`SetGameSetting fDifficultyDamageDealtMultiplierApprentice -2.5`
		`SetGameSetting fDifficultyDamageTakenMultiplierApprentice -2.5`
		`SetGameSetting fDifficultyDamageDealtMultiplierJourneyman 1.5`
		`SetGameSetting fDifficultyDamageTakenMultiplierJourneyman 1.5`
		`SetGameSetting fDifficultyDamageTakenMultiplierExpert 2.5`
		`SetGameSetting fDifficultyDamageDealtMultiplierExpert 2.5`
		`SetGameSetting fDifficultyDamageTakenMultiplierMaster 5`
		`SetGameSetting fDifficultyDamageDealtMultiplierMaster 5`

## Credits
1. Utilizes ObScript Extender created by [MadAborModding](https://next.nexusmods.com/profile/MadAborModding)
2. Utilizes MCM created by [MadAborModding](https://next.nexusmods.com/profile/MadAborModding)